#pragma once
#include <vector>
#include <map>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;

class Opt;
class Graph;
class Session;

#include "include/Graph.h"
#include "include/Opt.h"
#include "include/Session.h"

